package com.sri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJpaProj03LabTask2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
