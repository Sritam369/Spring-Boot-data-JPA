package com.sri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJpaProj04PagingAndSortingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJpaProj04PagingAndSortingApplication.class, args);
	}

}
